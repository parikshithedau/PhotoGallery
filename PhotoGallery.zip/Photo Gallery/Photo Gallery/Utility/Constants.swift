//
//  Constants.swift
//  Photo Gallery
//
//  Created by Parikshit Hedau on 02/07/18.
//  Copyright © 2018 parikshit.hedau. All rights reserved.
//

import Foundation
import UIKit

let PHOTO_FETCH_URL = "https://pixabay.com/api/"
let PIXBAY_API_KEY = "9444067-ed73daa529ebf0ba1f3d9bb78"

let APPNAME = "Photo Gallery"

//MARK :- Web Service
let PARSING_PROBLEM = "Problem in parsing server response. Please try again later."
let FETCHING_PROBLEM = "Problem in fetching response from server. Please try again later."
let RESPONSE_PROBLEM = "No response received from server. Please try again later."

// MARK: - Alert Text
let NO_INTERNET_MESSAGE = "No Internet Connection"

// MARK: - Notification Text
let INTERNET_CONNECTION_NOTIFICATION = "INTERNET_CONNECTION_NOTIFICATION"

//MARK :- Macros
let appDel = UIApplication.shared.delegate as! AppDelegate
