//
//  Utility.swift
//  Photo Gallery
//
//  Created by Parikshit Hedau on 02/07/18.
//  Copyright © 2018 parikshit.hedau. All rights reserved.
//

import Foundation
import UIKit
import Reachability
import ObjectMapper

//MARK :- Reachability Methods
var reachability = Reachability()!
var isInternetAvailable = false

func startReachability() {
    
    reachability.whenReachable = { reachability in

        isInternetAvailable = true
        
        JDStatusBarNotification.dismiss()
        
        if reachability.connection == .wifi {
            print("Reachable via WiFi")
        } else {
            print("Reachable via Cellular")
        }
        
        NotificationCenter.default.post(name: Notification.Name(rawValue: INTERNET_CONNECTION_NOTIFICATION), object: nil)
    }
    reachability.whenUnreachable = { _ in
        
        isInternetAvailable = false
        
        JDStatusBarNotification.show(withStatus: NO_INTERNET_MESSAGE, styleName: JDStatusBarStyleError)
        
        print("Not reachable")
    }
    
    do {
        try reachability.startNotifier()
    } catch {
        print("Unable to start notifier")
    }
}

//MARK :- ShowAlert
func showAlert(_ title:String?,_ message:String?) {
    
    let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
    let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil)
    alert.addAction(okAction)
    appDel.window?.rootViewController?.present(alert, animated: true, completion: nil)
}

//MARK :- RGB
func RGB(_ r:CGFloat, _ g:CGFloat, _ b:CGFloat, _ a:CGFloat) -> UIColor
{
    let color = UIColor(red: r/255.0, green: g/255.0, blue: b/255.0, alpha: a)
    
    return color
}

// MARK: - ProgressHud
func showProgressHUD() {
    
    let view = UIView(frame: CGRect(x: 0, y: 0, width: getScreenWidth(), height: getScreenHeight()))
    view.backgroundColor = UIColor.clear
    view.tag = -100
    appDel.window?.addSubview(view)
    
    let loader = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)
    loader.color = UIColor.orange
    loader.center = view.center
    loader.startAnimating()
    view.addSubview(loader)
}

func dismissHUD() {

    if let view = appDel.window?.viewWithTag(-100) {
        
        view.removeFromSuperview()
    }
}

//MARK :- Orientation Method
func getScreenWidth() -> CGFloat{
    
    return UIScreen.main.bounds.size.width
}

func getScreenHeight() -> CGFloat{
    
    return UIScreen.main.bounds.size.height
}
