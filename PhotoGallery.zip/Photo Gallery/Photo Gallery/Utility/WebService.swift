//
//  WebService.swift
//  Photo Gallery
//
//  Created by Parikshit Hedau on 02/07/18.
//  Copyright © 2018 parikshit.hedau. All rights reserved.
//

import UIKit

class WebService: NSObject {

    var counter = 0
    
    var dataTask : URLSessionDataTask? = nil
    
    var completionBlock: ((Any?, Bool, String)->())? = nil
    
    var shouldShowHUD = false
    
    func fetchPhotosFromServer(page:Int, limit:Int) {
        
        if !isInternetAvailable {
            
            self.completionBlock?(nil, false, NO_INTERNET_MESSAGE)
            
            return
        }
        
        if shouldShowHUD {
            
            showProgressHUD()
        }
        
        let strURL = "\(PHOTO_FETCH_URL)?q=nature&image_type=photo&page=\(page)&per_page=\(limit)&key=\(PIXBAY_API_KEY)"
        
        guard let url = URL(string: strURL) else {
            
            self.completionBlock?(nil, false, "Problem in server path.")
            
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        dataTask = URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
            
            DispatchQueue.main.async {

                dismissHUD()
                
                if error != nil {
                    
                    self.counter = self.counter + 1
                    
                    if self.counter == 1 {
                        
                        self.fetchPhotosFromServer(page: page, limit: limit)
                    }
                    else
                    {
                        self.callCompletionBlock(nil, false, FETCHING_PROBLEM)
                    }
                }
                else
                {
                    if let responseData = data {
                        
                        do {
                            
                            let response = try JSONSerialization.jsonObject(with: responseData, options: JSONSerialization.ReadingOptions.allowFragments)
                            self.completionBlock?(response, true, "")
                        }
                        catch{
                            
                            if let str = String(data: responseData, encoding: String.Encoding.utf8) {
                                
                                self.completionBlock?(nil, true, "")
                            }
                            else{
                                
                                self.completionBlock?(nil, false, PARSING_PROBLEM)
                            }
                        }
                    }
                    else
                    {
                        self.completionBlock?(nil, false, RESPONSE_PROBLEM)
                    }
                }
            }
        })
        
        dataTask?.resume()
    }
    
    func callCompletionBlock(_ data:Any?, _ status:Bool, _ msg:String) {
        
        self.completionBlock?(data, status, msg)
    }
    
    func cancelRequest() {
        
        dataTask?.cancel()
        dataTask = nil
        
        self.completionBlock = nil
    }
}
