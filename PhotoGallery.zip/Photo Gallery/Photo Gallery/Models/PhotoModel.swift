//
//  PhotoModel.swift
//  Photo Gallery
//
//  Created by Parikshit Hedau on 03/07/18.
//  Copyright © 2018 parikshit.hedau. All rights reserved.
//

import UIKit
import ObjectMapper

class PhotoModelList: Mappable {
    
    var arrayList: Array<PhotoModel>?
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        
        arrayList <- map["hits"]
    }
    
    static func mapObject(obj: [String : Any]) -> PhotoModelList? {
        
        if let model : PhotoModelList = Mapper().map(JSON: obj) {

            return model
        }
        
        return nil
    }
}

class PhotoModel: Mappable {

    var thumbURL: String?
    var webURL: String?
    var assetURL: String?
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        
        thumbURL <- map["previewURL"]
        webURL <- map["webformatURL"]
        assetURL <- map["largeImageURL"]
    }    
}
