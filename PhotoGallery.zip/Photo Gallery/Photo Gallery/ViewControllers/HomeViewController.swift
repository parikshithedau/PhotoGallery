//
//  HomeViewController.swift
//  Photo Gallery
//
//  Created by Parikshit Hedau on 02/07/18.
//  Copyright © 2018 parikshit.hedau. All rights reserved.
//

import UIKit

class PhotoCell: UICollectionViewCell {
    
    @IBOutlet weak var imgView: UIImageView!
}

class HomeViewController: UIViewController {

    @IBOutlet weak var collectionViewPhotos: UICollectionView!
    @IBOutlet weak var btnRefreshBtn: UIButton!
    
    var arrayPhotos = Array<PhotoModel>()
    
    let limit = 48
    var shouldLoadMore = false
    var isLoadingMore = false
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        btnRefreshBtn.isHidden = true

        NotificationCenter.default.addObserver(self, selector: #selector(loadPhotos), name: Notification.Name(rawValue: INTERNET_CONNECTION_NOTIFICATION), object: nil)

        SDWebImageManager.shared().imageDownloader?.maxConcurrentDownloads = 10
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.2) {
            
            self.fetchPhotos(isRefresh: true)
        }
    }
    
    // MARK: - IBActions
    @IBAction func refreshBtnClicked() {
        
        btnRefreshBtn.isHidden = true
        
        if !isInternetAvailable {
        
            btnRefreshBtn.isHidden = false
        }
        else{
            
            fetchPhotos(isRefresh: true)
        }
    }
    
    // MARK: - Utility Methods
    @objc func loadPhotos() {
        
        SDWebImageManager.shared().cancelAll()
        
        let visibleCells = collectionViewPhotos.visibleCells
        
        for cell in visibleCells {
            
            let photoCell = cell as? PhotoCell
            
            let indexPath = collectionViewPhotos.indexPath(for: photoCell!)!
            
            let photoModel = arrayPhotos[indexPath.row]
            
            if let webURL = photoModel.webURL {
                
                let url: URL? = URL(string:webURL)!
                
                SDWebImageManager.shared().loadImage(with: url, options: SDWebImageOptions.cacheMemoryOnly, progress: nil) { (img, data, err, type, success, url) in
                    
                    if photoCell != nil {
                        
                        if let index = self.collectionViewPhotos.indexPath(for: photoCell!) {
                            
                            if indexPath.row == index.row {
                                
                                photoCell?.imgView.image = img
                            }
                        }
                    }
                    else{
                        
                        photoCell?.imgView.image = nil
                    }
                }
            }
        }
    }
    
    //MARK :-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

// MARK: - Server Request Methods
extension HomeViewController {
    
    @objc func fetchPhotos(isRefresh: Bool) {
        
        let webService = WebService()
        
        webService.completionBlock = ({ data, success, message in
            
            self.shouldLoadMore = false
            self.isLoadingMore = false
            
            self.btnRefreshBtn.isHidden = true
            
            if success {
                
                if let dict = data as? Dictionary<String,Any> {
                    
                    if let model = PhotoModelList.mapObject(obj: dict) {
                        
                        if model.arrayList?.count == self.limit {
                            
                            self.shouldLoadMore = true
                        }
                        else{
                            
                            self.shouldLoadMore = false
                        }
                        
                        let count = self.arrayPhotos.count
                        
                        self.arrayPhotos.append(contentsOf: model.arrayList!)
                        
                        self.collectionViewPhotos.reloadData()
                        
                        if count == 0 {
                            
                            self.perform(#selector(self.loadPhotos), with: nil, afterDelay: 0.1)
                        }
                    }
                    else{
                        
                        print(dict)
                        showAlert(APPNAME, PARSING_PROBLEM)
                    }
                }
            }
            else{
                
                if !isInternetAvailable {
                    
                    if self.arrayPhotos.count == 0 {
                        
                        self.btnRefreshBtn.isHidden = false
                    }
                }
                else{
                    
                    showAlert(APPNAME, message)
                }
            }
        })
        
        webService.shouldShowHUD = isRefresh
        
        let page = Int(arrayPhotos.count/limit) + 1
        
        webService.fetchPhotosFromServer(page: page, limit: limit)
    }
}

// MARK: - CollectionView Delegate & DataSource Methods
extension HomeViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arrayPhotos.count;
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCell
        
        cell.imgView.image = nil
        
        cell.backgroundColor = RGB(245, 245, 245, 1.0)
        
        let photoModel = arrayPhotos[indexPath.row]
        
        var url: URL? = nil

        if let webURL = photoModel.webURL {
            
            url = URL(string:webURL)!
        }
        
        if let image = SDImageCache.shared().imageFromCache(forKey: url?.absoluteString)
        {
            cell.imgView.image = image
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        
        if indexPath.row > arrayPhotos.count-10 && !isLoadingMore && shouldLoadMore {
            
            isLoadingMore = true
            fetchPhotos(isRefresh: false)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let cell = collectionView.cellForItem(at: indexPath)
        
        var arrayItems = Array<IDMPhoto>()
        
        for photoModel in arrayPhotos {
            
            let item = IDMPhoto(url: URL(string: photoModel.assetURL!))
            
            arrayItems.append(item!)
        }
        
        let browser = IDMPhotoBrowser(photos: arrayItems, animatedFrom: cell)
        browser?.setInitialPageIndex(UInt(indexPath.row))
        browser?.displayCounterLabel = true
        browser?.autoHideInterface = false
        browser?.doneButtonImage = #imageLiteral(resourceName: "close")
        self.present(browser!, animated: true, completion: nil)
    }
}

// MARK: - Scrollview Delegate Methods
extension HomeViewController: UIScrollViewDelegate {

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        NSObject.cancelPreviousPerformRequests(withTarget: self)
        
        self.perform(#selector(scrollViewDidEndScrollingAnimation(_:)), with: scrollView, afterDelay: 0.3)
    }
    
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        
        NSObject.cancelPreviousPerformRequests(withTarget: self)
        
        loadPhotos()
    }
}
